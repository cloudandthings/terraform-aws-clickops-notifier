import re
import json
import logging
from typing import Tuple, List

logger = logging.getLogger(__name__)


class CloudTrailEvent:
    def __init__(self, event) -> None:

        self.user_agent = event.get("userAgent", "Unknown User Agent")
        self.event_name = event["eventName"]
        self.event_source = event["eventSource"]
        self.request_id = event.get("requestID", "NA")
        self.read_only = self.__readonly_event(event)
        self.user_email = self.__user_email(event)
        self.console_session = self.__console_session_event(event)

    EMAIL_RE = re.compile(r"[\w.+-]+@[\w-]+\.[\w.-]+")

    @staticmethod
    def __user_email(event) -> str:
        if "userIdentity" not in event:
            logger.debug("No userIdentity in event, returning Unknown")
            return "Unknown"

        user_identity = event["userIdentity"]

        # Try to get email from principalId if it exists
        # e.g. "AROAXK4KVD27BINQTHSKU:paul@cloudandthings.io"
        if "principalId" in user_identity:
            parts = user_identity["principalId"].split(":")
            if len(parts) > 1 and CloudTrailEvent.EMAIL_RE.fullmatch(parts[1]):
                return parts[1]
            logger.debug(
                "principalId '%s' did not contain an email",
                user_identity["principalId"],
            )

        # Try to get email from userName if it exists
        if "userName" in user_identity:
            if CloudTrailEvent.EMAIL_RE.fullmatch(user_identity["userName"]):
                return user_identity["userName"]
            logger.debug(
                "userName '%s' is not an email, will try other fields",
                user_identity["userName"],
            )

        # Try to get email from arn if it exists
        if "arn" in user_identity:
            match = CloudTrailEvent.EMAIL_RE.search(user_identity["arn"])
            if match:
                return match.group(0)
            logger.debug("No email found in arn '%s'", user_identity["arn"])

        # Try to get email from the entire userIdentity object
        match = CloudTrailEvent.EMAIL_RE.search(json.dumps(user_identity))
        if match:
            logger.debug("Email found via full userIdentity scan: %s", match.group(0))
            return match.group(0)

        # Fall back to userName if available, even if not an email
        if "userName" in user_identity:
            logger.debug(
                "No email found, falling back to non-email userName '%s'",
                user_identity["userName"],
            )
            return user_identity["userName"]

        logger.debug("No email or userName found in userIdentity, returning Unknown")
        return "Unknown"

    @staticmethod
    def __readonly_event(event) -> bool:
        if "readOnly" in event:
            if (
                event["readOnly"] == "true"
                or event["readOnly"]
                or event["readOnly"] == 1
            ):
                return True
            else:
                return False
        else:
            return False

    @staticmethod
    def __console_session_event(event) -> bool:
        if "sessionCredentialFromConsole" in event:
            if (
                event["sessionCredentialFromConsole"] == "true"
                or event["sessionCredentialFromConsole"]
                or event["sessionCredentialFromConsole"] == 1
            ):
                return True
            else:
                return False
        else:
            return False


class ClickOpsEventChecker:
    def __init__(
        self, event: CloudTrailEvent, ignored_scoped_events: List[str]
    ) -> None:

        self.READONLY_EVENTS_RE = [
            "^Get",
            "^Describe",
            "^List",
            "^Head",
        ]

        self.IGNORED_SCOPED_EVENTS = ignored_scoped_events

        self.IGNORED_EVENTS = {
            "DownloadDBLogFilePortion",
            "TestScheduleExpression",
            "TestEventPattern",
            "LookupEvents",
            "listDnssec",
            "Decrypt",
            "REST.GET.OBJECT_LOCK_CONFIGURATION",
            "ConsoleLogin",
        }

        self.USER_AGENTS_RE = [
            "signin.amazonaws.com(.*)",
            "^S3Console",
            "^\[S3Console",  # noqa: W605
            "^Mozilla/",
            "^console(.*)amazonaws.com(.*)",
            "^aws-internal(.*)AWSLambdaConsole(.*)",
        ]

        self.USER_AGENTS = {"console.amazonaws.com", "Coral/Jakarta", "Coral/Netty4"}

        self.event = event

    @staticmethod
    def check_regex(expr, txt) -> bool:
        match = re.search(expr, txt)
        return match is not None

    def __match_readonly_event_name_pattern(self) -> bool:
        for expression in self.READONLY_EVENTS_RE:
            if self.check_regex(expression, self.event.event_name):
                return True

        return False

    def __match_ignored_event_names(self) -> bool:
        return self.event.event_name in self.IGNORED_EVENTS

    def __match_ignored_scoped_events(self) -> bool:
        return (
            f"{self.event.event_source}:{self.event.event_name}"
            in self.IGNORED_SCOPED_EVENTS
        )  # noqa: E501

    def __user_agent_console(self) -> bool:

        user_agent = self.event.user_agent

        if user_agent in self.USER_AGENTS:
            return True

        for expresion in self.USER_AGENTS_RE:
            if self.check_regex(expresion, user_agent):
                return True

        return False

    def is_clickops(self) -> Tuple[bool, str]:

        if self.event.read_only:
            return False, "[COEC_Rule1] Readonly Event"

        if not self.__user_agent_console() and not self.event.console_session:
            return False, "[COEC_Rule2] User agent does not match console"

        if self.__match_readonly_event_name_pattern():
            return False, "[COEC_Rule3] Match readonly event name pattern"

        if self.__match_ignored_event_names():
            return False, "[COEC_Rule4] Match ignored ignored event names"

        if self.__match_ignored_scoped_events():
            return False, "[COEC_Rule5] Match ignored ignored event names"

        return True, "[COEC_Rule6] Could not match any exclusions"
